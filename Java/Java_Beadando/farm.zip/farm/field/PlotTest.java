package farm.field;

import farm.crop.Crop;
import farm.crop.CropType;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlotTest {

    @Test
    void testPlantAndRemove() {
        Plot plot = new Plot();
        assertTrue(plot.isEmpty()); // Kezdetben üres

        plot.plant(new Crop(CropType.CORN));
        assertFalse(plot.isEmpty()); // Most már nem üres

        plot.removeCrop();
        assertTrue(plot.isEmpty()); // Eltávolítás után újra üres
    }

    @Test
    void testPlantOnOccupiedPlotFails() {
        Plot plot = new Plot();
        plot.plant(new Crop(CropType.LETTUCE));
        
        // Ha újra próbálunk ültetni rá, hibát kell dobnia (IllegalStateException)
        assertThrows(IllegalStateException.class, () -> {
            plot.plant(new Crop(CropType.CORN));
        });
    }
}