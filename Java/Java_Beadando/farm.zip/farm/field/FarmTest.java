package farm.field;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FarmTest {

    @Test
    void testFarmInitialization() {
        Farm farm = new Farm(3, 5);
        // Ellenőrizzük, hogy létrejöttek-e a parcellák
        // (Ehhez kell, hogy a getRows/getCols működjön, vagy a getPlot ne dobjon hibát)
        assertNotNull(farm.getPlot(0, 0));
        assertNotNull(farm.getPlot(2, 4));
        
        // Túlindexelés ellenőrzése (opcionális, de hasznos)
        assertThrows(IllegalArgumentException.class, () -> farm.getPlot(3, 0));
    }
}