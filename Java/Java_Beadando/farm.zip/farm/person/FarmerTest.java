package farm.person;

// Nagyon fontos importok, mert a Farmer más csomagokban lévő osztályokat használ!
import farm.crop.Crop;
import farm.crop.CropType;
import farm.field.Farm;
import farm.field.Plot;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

public class FarmerTest {

    @DisplayName("Ültetés és öntözés ellenőrzése")
    @Test
    void testPlantCropAndWater() { 
        Farm farm = new Farm(3, 3);
        Farmer farmer = new Farmer("Jani", farm);

        farmer.plantCrop(0, 0, CropType.CORN);
        farmer.waterCrop(0, 0);

        Plot plot = farm.getPlot(0, 0);
        assertFalse(plot.isEmpty());
        // A víznek 2-nek kell lennie
        assertEquals(2, plot.getCrop().getWaterAmount());
    }

    @DisplayName("Érett növény betakarítása kiüríti a parcellát")
    @Test
    void testHarvestRemovesMatureCrop() { 
        Farm farm = new Farm(2, 2);
        Farmer farmer = new Farmer("Jani", farm);
        farmer.plantCrop(0, 0, CropType.LETTUCE);

        // Növesztés (biztosan érett legyen)
        for (int i = 0; i < 15; i++) {
            farmer.waterCrop(0, 0);
            farmer.simulateDay();
        }

        // Betakarítás
        farmer.harvestCrop(0, 0); 
        
        assertTrue(farm.getPlot(0, 0).isEmpty(), "A parcellának üresnek kell lennie betakarítás után");
        assertEquals(1, farmer.getHarvestedCrops().size());
    }

    @DisplayName("Elpusztult növény eltávolítása (Clean)")
    @Test
    void testCleanDeadCrop() { 
        Farm farm = new Farm(1, 1);
        Farmer farmer = new Farmer("Jani", farm);
        farmer.plantCrop(0, 0, CropType.STRAWBERRY); // maxDryDays = 1

        farmer.simulateDay();
        farmer.simulateDay(); // 2 nap víz nélkül -> Halott

        farmer.cleanPlot(0, 0);
        
        assertTrue(farm.getPlot(0, 0).isEmpty(), "A halott növényt el kellett volna takarítani");
    }

    @DisplayName("A legszomjasabb növény öntözése")
    @Test
    void testWaterMostThirstyCrop() { 
        Farm farm = new Farm(2, 2);
        Farmer farmer = new Farmer("Jani", farm);
        
        farmer.plantCrop(0, 0, CropType.CORN); // 'A'
        farmer.waterCrop(0, 0); // Víz = 2
        
        farmer.plantCrop(0, 1, CropType.CORN); // 'B' -> Víz = 0 (SZOMJASABB)

        // A 'B'-t (0,1) kell választania
        farmer.waterMostThirstyCrop();

        assertEquals(2, farm.getPlot(0, 1).getCrop().getWaterAmount(), "A szomjasabb növényt kellett volna meglocsolni");
    }

    @DisplayName("Komplex szimulációs esetek ellenőrzése (5 eset)")
    @ParameterizedTest(name = "{0}({1}x) és {2}({3}x) -> {5} nap -> Betakarítva: {6}")
    @CsvSource(textBlock = """
        LETTUCE, 12, CORN, 12, 12, 1
        LETTUCE, 12, STRAWBERRY, 12, 12, 2
        LETTUCE, 0,  CORN, 12, 12, 0
        LETTUCE, 0,  STRAWBERRY, 12, 12, 1
        STRAWBERRY, 0, STRAWBERRY, 0, 5, 0
    """)
    void testFarmerSimulationWithHarvest(
            CropType type1, int water1, 
            CropType type2, int water2, 
            int days, int expectedHarvest) {
        
        Farm farm = new Farm(2, 1); 
        Farmer farmer = new Farmer("Tesztelő", farm);

        // Ültetés
        farmer.plantCrop(0, 0, type1);
        farmer.plantCrop(1, 0, type2);

        // Szimuláció futtatása
        for (int d = 0; d < days; d++) {
            if (d < water1) farmer.waterCrop(0, 0);
            if (d < water2) farmer.waterCrop(1, 0);

            farmer.simulateDay();
            
            farmer.harvestCrops(type1);
            farmer.harvestCrops(type2);
        }

        // Ellenőrzés
        assertEquals(expectedHarvest, farmer.getHarvestedCrops().size());
    }
}