package farm.crop;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CropTest {

    @DisplayName("simulateDay() csökkenti a vizet 1-gyel")
    @Test
    void testWaterDecayAfterSimulateDay() { 
        Crop crop = new Crop(CropType.CORN);
        crop.water(); // Víz = 2 (mert 0-ról indul + 2)
        
        crop.simulateDay(); // Eltelik egy nap
        
        // Víz = 1 kell legyen
        assertEquals(1, crop.getWaterAmount());
    }

    @DisplayName("Ha van víz, a növény nő a growthRate szerint")
    @Test
    void testGrowthOccursWhenWatered() { 
        // LETTUCE growthRate: 3
        Crop crop = new Crop(CropType.LETTUCE);
        crop.water(); // Van vize
        
        crop.simulateDay(); // Nőnie kell
        
        // Mivel a growthLevel privát, közvetve ellenőrizzük:
        // Nem lehet halott
        assertFalse(crop.isDead());
        // Ha van getGrowthLevel() metódusod, akkor: assertEquals(3, crop.getGrowthLevel());
    }

    @DisplayName("Különböző növények halála szárazság esetén")
    @Test
    void testDifferentDeathThresholds() { 
        // STRAWBERRY: maxDryDays = 1
        Crop strawberry = new Crop(CropType.STRAWBERRY);
        
        strawberry.simulateDay(); // 1 nap szárazság -> még él (mert limit = 1)
        assertFalse(strawberry.isDead());

        strawberry.simulateDay(); // 2 nap szárazság -> 2 > 1 -> halott
        assertTrue(strawberry.isDead());

        // CORN: maxDryDays = 3
        Crop corn = new Crop(CropType.CORN);
        corn.simulateDay(); // 1 nap
        corn.simulateDay(); // 2 nap
        corn.simulateDay(); // 3 nap -> még él
        assertFalse(corn.isDead());
        
        corn.simulateDay(); // 4 nap -> halott
        assertTrue(corn.isDead());
    }

    @DisplayName("isMature() helyesen működik")
    @Test
    void testIsMature() { 
        // LETTUCE: maturity 30.
        Crop crop = new Crop(CropType.LETTUCE);
        
        // Csalunk: sokszor locsoljuk és léptetjük
        for (int i = 0; i < 9; i++) {
            crop.water();
            crop.simulateDay();
        }
        // 9 * 3 = 27 < 30 -> Még nem érett
        assertFalse(crop.isMature()); 

        crop.water();
        crop.simulateDay();
        // 10 * 3 = 30 >= 30 -> Érett
        assertTrue(crop.isMature()); 
    }

    @DisplayName("Betakarítás sikertelen, ha nem érett vagy halott")
    @Test
    void testHarvestFailsWhenNotMatureOrDead() { 
        Crop youngCrop = new Crop(CropType.CORN);
        assertFalse(youngCrop.harvest(), "Nem érett növényt nem lehet learatni");

        Crop deadCrop = new Crop(CropType.STRAWBERRY);
        deadCrop.simulateDay();
        deadCrop.simulateDay(); // Meghalt
        assertFalse(deadCrop.harvest(), "Halott növényt nem lehet learatni");
    }

    @DisplayName("Sikeres betakarítás alaphelyzetbe állítja a növényt")
    @Test
    void testHarvestSuccess() { 
        Crop crop = new Crop(CropType.LETTUCE);
        // Megnövesztjük érettre
        for (int i = 0; i < 10; i++) {
            crop.water();
            crop.simulateDay();
        }
        
        assertTrue(crop.harvest()); // Sikerült aratni?
        assertEquals(0, crop.getWaterAmount()); // Resetelődött a víz?
    }
}